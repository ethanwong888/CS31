#define _CRT_SECURE_NO_DEPRECATE
#include "utilities.h"
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

const char WORDFILENAME[] = "C:/Users/e1234/OneDrive/Desktop/mywordfile.txt";  //  "/u/cs/ugrad/yee/proj5/mywordfile.txt";   (this is the version of mywordfile.txt on the linux server)
int playOneRound(const char words[][7], int nWords, int wordnum);
bool legalTrial(const char trialword[], const char words[][7], int nWords);
int trialSearch(const char trialword[], const char target[]);


int main()
{
	char wordList[9000][7];                                //declares array of C strings
	int nWords = getWords(wordList, 10000, WORDFILENAME);  //declares int to hold number of words in the array

	if (nWords < 1)
	{
		cout << "No words were loaded, so I can't play the game." << endl;
		return 0;
	}

	cout << "How many rounds do you want to play? ";   //user is asked how many rounds they want to play
	int totalRounds;
	cin >> totalRounds;
	cin.ignore(10000, '\n');

	if (totalRounds < 1)   //user must enter a value greater than 0 to play the game
	{
		cout << "The number of rounds must be positive." << endl;
		return 0;
	}

	double totalTries = 0;
	int amtOfAttempts;
	int min = INT8_MAX;
	int max = INT8_MIN;


	for (int a = 0; a < totalRounds; a++)        //iterate through the number of rounds
	{
		cout << "Round " << a + 1 << endl;       //outputs "Round 1", "Round 2", etc. 
		int random = randInt(0, nWords - 1);     //provides random integer between minimum and maximum

		cout << "The mystery word is " << strlen(wordList[random]) << " letters long." << endl;

		amtOfAttempts = playOneRound(wordList, nWords, random);  //stores amount of tries 

		if (amtOfAttempts == 1)
			cout << "You got it in 1 try." << endl;
		else
			cout << "You got it in " << amtOfAttempts << " tries." << endl;

		if (amtOfAttempts > max)
			max = amtOfAttempts;      //if amtOfAttempts is greater than the current max, it becomes the new max
		if (amtOfAttempts < min)
			min = amtOfAttempts;      //if amtOfAttempts is less than the current min, it becomes the new min
		totalTries += amtOfAttempts;

		cout.setf(ios::fixed);
		cout.precision(2);

		cout << "Average: " << totalTries / (a + 1) << ", minimum: " << min << ", maximum: " << max << endl;  //displays statistics about how well the player has played the round so far
	}
}

int playOneRound(const char words[][7], int nWords, int wordnum)  //function takes in an array of C strings, the number of words in the array, and an int index
{
	if (nWords < 1 || wordnum < 0 || wordnum >= nWords)  //conditions that would cause the program to crash
	{
		return -1;
	}

	char trialWord[101];

	int attempts = 0;

	while (strcmp(words[wordnum], trialWord) != 0)   //while the target and trial array aren't the same
	{
		cout << "Trial word: ";   //prompts user to input a trial word
		cin.getline(trialWord, 101, '\n');

		if (strcmp(words[wordnum], trialWord) == 0)  //while the target and trial array are the same
		{
			attempts++;
			break;             //breaks out of the while loop if the two arrays are the same
		}

		if (legalTrial(trialWord, words, nWords))                //if the probe word is legal
			attempts += trialSearch(trialWord, words[wordnum]);  //probe the word and add one to attempts
	}
	return attempts;	      //when the target word is aquired, return number of attempts it took to guess it
}

int trialSearch(const char trialword[], const char target[])   //function that outputs intermediate
{
	bool samePosition[] = { false, false, false, false, false, false };  //array to track if two characters are the same at the same position
	bool foundBees[] = { false, false, false, false, false, false };     //array to track if a Bee was found in the array
	int flowers = 0;
	int bees = 0;

	for (int x = 0; target[x] != '\0'; x++)   //loops through target array
	{
		if (trialword[x] == target[x])        //if the positions have the same character, set both boolean array values to true at the element
		{
			flowers++;
			samePosition[x] = true;
			foundBees[x] = true;
		}
	}

	for (int x = 0; trialword[x] != '\0'; x++)                  //loop through the trial array
	{
		if (samePosition[x])                                    //if the current element is a flower, move on to next element
			continue;

		for (int y = 0; target[y] != '\0'; y++)                 //loop through the target array
			if (target[y] == trialword[x] && !foundBees[y])     //if the target and probe elements are the same and the current element hasn't been found yet
			{
				flowers++;
				foundBees[y] = true;                            //set the current element in the foundBees array to true, then move on to next element in the probe array
				break;
			}
	}
	cout << "Flowers: " << flowers << ", Bees: " << bees << endl;
	return 1;
}

bool legalTrial(const char trialword[], const char words[][7], int nWords)   //function that takes in a trialword array, the words array, and an int of number of words
{	   
		if (strlen(trialword) < 4 || strlen(trialword) > 6) //if the trialword is not 4-6 characters, print error message and return false
		{
			cout << "Your trial word must be a word of 4 to 6 lower case letters." << endl;
			return false;
		}

	for (int n = 0; trialword[n] != '\0'; n++)    //if the trialword contains non-lowercase characters, print error message and return false
	{
		if (!islower(trialword[n]) || !isalpha(trialword[n])) 
		{
			cout << "Your probe word must be a word of 4 to 6 lower case letters." << endl;
			return false;
		}
	}

	for (int x = 0; x < nWords; x++)       //if trialword is in the valid words array, return true                
		if (strcmp(trialword, words[x]) == 0)
			return true;

	cout << "I don't know that word." << endl;    //if it goes through the valid words array and doesn't exist, print error message and return false         
	return false;
}





